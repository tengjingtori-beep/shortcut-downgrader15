# ShortcutDowngrader15

iPhone 7 / iOS 15 向け。iOS 16〜27 で作られたショートカット (.shortcut) を、
iOS 15 のショートカットアプリで取り込める形式に変換するアプリです。
TrollStore でインストールできる無署名 IPA をビルドするプロジェクト一式です。

## 正直な前提（できること / できないこと）

- **できる**: ショートカットファイルの形式変換。
  - 最小クライアントバージョン等を iOS 15 世代にダウングレード
  - iOS 15 に無いアクションを、代替アクション / コメント / 削除に変換（置換・削除時も UUID を引き継ぐので「前のアクションの出力」参照が切れません）
  - iOS 18 以降の新形式「条件 (If)」パラメータを iOS 15 形式に変換
  - iOS 15 が知らないパラメータキーの除去
  - 変換レポート表示（どのアクションをどう変えたか）
- **できない**: Apple Intelligence や新しいシステム API そのものを iPhone 7 / iOS 15 で実行すること。
  該当アクションは代替手段に置き換わります。例:
  - AI に質問 / モデルを使用 / ChatGPT に質問 → 「入力を要求」（プロンプト文字列は引き継ぎ）
  - オーディオを転写 (iOS 17) → 「テキストを音声入力」
  - 停止して出力 (iOS 16) → 「結果を表示」+「ショートカットを終了」
  - 画面上のコンテンツを取得 (iOS 17) → 「クリップボードを取得」
  - コントロールセンターのトグル (iOS 18) → Wi-Fi / Bluetooth / 機内モード等の個別アクション
  - 画像生成 (Image Playground 等) → 代替なしのためコメント化
- カタログに無い未来のアクションも、`is.workflow.actions.*` のホワイトリスト照合と
  App Intents 形式の検出で「非対応」として拾います。新アクションは
  `ActionCatalog.swift` に 1 行足せば個別対応できます。

## 構成

```
ShortcutDowngrader15.xcodeproj   Xcode プロジェクト (そのまま開けます)
project.yml                      XcodeGen 用 (任意)
ShortcutDowngrader15/
  ShortcutDowngrader15App.swift  エントリポイント
  ContentView.swift              画面 + ViewModel (iOS 15 対応 SwiftUI)
  ConversionEngine.swift         変換エンジン本体
  ActionCatalog.swift            新アクションのカタログ / ホワイトリスト
  ShortcutParser.swift           .shortcut / .wflow / 署名付きファイルの読み込み
  Models.swift, Helpers.swift
  Info.plist, *.entitlements
build_trollstore_ipa.sh          IPA ビルドスクリプト (Mac 用)
Tools/shortcut_downgrade.py      同じ変換ロジックの CLI 版 (Mac 不要・検証済み)
Tests/                           サンプル (iOS 27 想定) と変換結果・レポート
```

## Mac が無い場合（推奨ルート）

GitHub Actions の macOS ランナーで自動ビルドできます。同梱の
`.github/workflows/build-trollstore-ipa.yml` と `iPhoneだけでビルドする手順.md` を参照。
アップロードは「ワークフロー」と「このプロジェクトの ZIP」の 2 ファイルだけで、
ビルド成功すると TrollStore 用 `.tipa` が Artifacts からダウンロードできます。

## IPA のビルド（Mac + Xcode がある場合）

このプロジェクトの作成環境は Linux で Xcode が無いため、コンパイル済み IPA は同梱していません。
Mac で以下を実行すると TrollStore 用 IPA ができます。

```bash
./build_trollstore_ipa.sh
# -> build/ShortcutDowngrader15.tipa
```

できた `.tipa` を iPhone に送り、TrollStore で開いてインストールしてください。
対応: iOS 15.0 以降 / iPhone 7 (arm64)。署名は不要です (CODE_SIGNING_ALLOWED=NO でビルドし、
必要なら ldid でフェイクサインします)。

Xcode で直接開く場合も、`IPHONEOS_DEPLOYMENT_TARGET = 15.0` 設定済みです。
Xcode 16 以降では iOS 15 が下限に近いので、警告が出たら Deployment Target を 15.0 のまま維持してください。

## 使い方

1. アプリを起動し、変換方法（推奨:「代替アクションに置換」）を選ぶ
2. 「ショートカットファイルを選ぶ」から `.shortcut` / `.wflow` を選ぶ
3. 変換レポートを確認し、「変換済みファイルを共有 / 保存」で書き出す
   (ファイル名は `元の名前-iOS15.shortcut`)

## 重要: iOS 15 への取り込みと署名

iOS 15 のショートカットアプリは、ファイルから取り込む場合に**署名付き**ショートカットを求めることがあります。
変換後のファイルが未署名で取り込めない場合は、Mac で署名してから iPhone に送ってください。

```bash
shortcuts sign --mode anyone --input "変換後-iOS15.shortcut" --output "変換後-iOS15-signed.shortcut"
```

(macOS Monterey 以降の `shortcuts` CLI を使用。署名したファイルは AirDrop 等で送り、タップすれば取り込めます)

署名付き `.shortcut` を変換する場合、本アプリは AEA コンテナ内の平文プリストを取り出しますが、
取り出せない形式ではエラーになります。その場合は iCloud リンク経由の未署名ファイルで試してください。

## CLI 版（アプリをビルドせず今すぐ試せます）

```bash
python3 Tools/shortcut_downgrade.py 入力.shortcut -o 出力.shortcut --report report.json
# --policy replace(既定) / comment / remove / keep
```

検証済み: `Tests/sample_ios27.shortcut` (AI アクション、転写、停止して出力、
現在 App 取得、新形式 If、未知の未来アクションを含む) を変換し、
バージョン降格・置換・UUID 維持・条件フラット化・未知キー除去を
`Tests/sample_ios15.shortcut` と `Tests/report.json` で確認しています。
