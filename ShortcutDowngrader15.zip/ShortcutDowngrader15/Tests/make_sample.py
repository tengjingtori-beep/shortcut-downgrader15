#!/usr/bin/env python3
"""iOS 27 世代の新アクションを含むテスト用ショートカットを生成する。"""
import plistlib

workflow = {
    "WFWorkflowMinimumClientVersion": 3000,
    "WFWorkflowMinimumClientVersionString": "3000",
    "WFWorkflowClientVersion": "9999.1",
    "WFWorkflowClientRelease": "27.0.0",
    "WFWorkflowHasOutputFallback": True,
    "WFWorkflowIcon": {"WFWorkflowIconStartColor": 4282601983, "WFWorkflowIconGlyphNumber": 61440},
    "WFWorkflowActions": [
        {"WFWorkflowActionIdentifier": "is.workflow.actions.comment",
         "WFWorkflowActionParameters": {"WFCommentActionText": "テスト用ショートカット"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.appleintelligence.ask",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000001",
                                        "WFAskActionPrompt": "この文章を要約して",
                                        "WFAppIntentDescriptor": {"x": 1}}},
        {"WFWorkflowActionIdentifier": "com.openai.chat.AskChatGPTAction",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000002"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.transcribeaudio",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000003"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.output",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000004"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.getcurrentapp",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000005"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.teleport",
         "WFWorkflowActionParameters": {"UUID": "AAAA1111-0000-0000-0000-000000000006"}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.conditional",
         "WFWorkflowActionParameters": {
             "WFControlFlowMode": 0, "GroupingIdentifier": "BBBB2222-0000-0000-0000-000000000001",
             "WFConditions": {"WFConditionGroups": [
                 {"WFConditions": [{"WFCondition": 4, "WFNumberValue": 5}]}]}}},
        {"WFWorkflowActionIdentifier": "is.workflow.actions.text",
         "WFWorkflowActionParameters": {"WFTextActionText": "完了", "WFAppIntentDescriptor": {"y": 2}}},
    ],
}

with open("sample_ios27.shortcut", "wb") as f:
    plistlib.dump(workflow, f, fmt=plistlib.FMT_BINARY)
print("sample_ios27.shortcut を生成しました")
