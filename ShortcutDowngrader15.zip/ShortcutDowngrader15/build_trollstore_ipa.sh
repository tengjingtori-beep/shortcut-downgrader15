#!/bin/bash
# Mac (Xcode) 上で実行すると、TrollStore でインストールできる
# 無署名 .ipa を build/ShortcutDowngrader15.tipa として生成する。
# 使い方:  ./build_trollstore_ipa.sh
set -euo pipefail
cd "$(dirname "$0")"

if ! xcodebuild -version >/dev/null 2>&1; then
  echo "Xcode が必要です (Mac App Store からインストールしてください)。" >&2
  exit 1
fi

# XcodeGen があれば project.yml からプロジェクトを再生成 (任意)
if command -v xcodegen >/dev/null 2>&1; then
  xcodegen generate
fi

APP_NAME="ShortcutDowngrader15"
BUILD_DIR="$(pwd)/build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/Payload"

xcodebuild \
  -project "$APP_NAME.xcodeproj" \
  -scheme "$APP_NAME" \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$BUILD_DIR/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  build

APP_PATH="$BUILD_DIR/DerivedData/Build/Products/Release-iphoneos/$APP_NAME.app"
test -d "$APP_PATH" || { echo ".app が見つかりません: $APP_PATH" >&2; exit 1; }

cp -R "$APP_PATH" "$BUILD_DIR/Payload/"

# ldid があれば entitlements 付きでフェイクサイン (TrollStore では無くても可)
if command -v ldid >/dev/null 2>&1; then
  ldid -S"$APP_NAME/$APP_NAME.entitlements" "$BUILD_DIR/Payload/$APP_NAME.app/$APP_NAME" || true
fi

cd "$BUILD_DIR"
zip -qry "ShortcutDowngrader15.tipa" Payload
echo "完成: $BUILD_DIR/ShortcutDowngrader15.tipa"
echo "このファイルを iPhone に送り、TrollStore で開いてインストールしてください。"
