import SwiftUI
import UniformTypeIdentifiers

final class ConverterViewModel: ObservableObject {
    @Published var policy: UnsupportedPolicy = .replaceWithFallback
    @Published var outcome: ConversionOutcome?
    @Published var outputURL: URL?
    @Published var errorMessage: String?
    @Published var isImporterPresented = false
    @Published var isSharePresented = false

    func handlePickedFile(url: URL) {
        errorMessage = nil
        outcome = nil
        outputURL = nil
        do {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            let raw = try Data(contentsOf: url)
            let workflow = try ShortcutParser.extractWorkflow(from: raw)
            let result = try ConversionEngine.convert(workflow: workflow,
                                                      fileName: url.lastPathComponent,
                                                      policy: policy)
            // 共有用に一時ファイルへ書き出す (.shortcut として書き出す)
            let tmp = FileManager.default.temporaryDirectory
                .appendingPathComponent(result.outputFileName)
            try result.outputData.write(to: tmp, options: .atomic)
            outcome = result
            outputURL = tmp
        } catch {
            errorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}

struct ContentView: View {
    @StateObject private var model = ConverterViewModel()

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("変換方法")) {
                    Picker("非対応アクション", selection: $model.policy) {
                        ForEach(UnsupportedPolicy.allCases) { policy in
                            Text(policy.label).tag(policy)
                        }
                    }
                    Text("Apple Intelligence など iOS 15 / iPhone 7 に無い機能そのものは実行できません。該当箇所は代替アクションかコメントに置き換わります。")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                Section {
                    Button {
                        model.isImporterPresented = true
                    } label: {
                        Label("ショートカットファイルを選ぶ", systemImage: "square.and.arrow.down")
                    }
                    if let outcome = model.outcome {
                        Button {
                            model.isSharePresented = true
                        } label: {
                            Label("変換済みファイルを共有 / 保存", systemImage: "square.and.arrow.up")
                        }
                        Text("\(outcome.workflowName): 全 \(outcome.totalActions) アクション中 \(outcome.changedCount) 件を変更")
                            .font(.footnote)
                    }
                    if let error = model.errorMessage {
                        Text(error).foregroundColor(.red).font(.footnote)
                    }
                }

                if let outcome = model.outcome, !outcome.reports.isEmpty {
                    Section(header: Text("変換レポート")) {
                        ForEach(outcome.reports) { report in
                            VStack(alignment: .leading, spacing: 2) {
                                Text("\(report.decision.rawValue): \(report.originalIdentifier)")
                                    .font(.footnote).bold()
                                if let replacement = report.replacementIdentifier {
                                    Text("→ \(replacement)").font(.footnote)
                                }
                                Text(report.note).font(.footnote).foregroundColor(.secondary)
                            }
                        }
                    }
                }
            }
            .navigationTitle("iOS 15 変換")
            .fileImporter(isPresented: $model.isImporterPresented,
                          allowedContentTypes: [.shortcutFile, .propertyList, .data],
                          allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first {
                    model.handlePickedFile(url: url)
                }
            }
            .sheet(isPresented: $model.isSharePresented) {
                if let url = model.outputURL {
                    ShareSheet(items: [url])
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
