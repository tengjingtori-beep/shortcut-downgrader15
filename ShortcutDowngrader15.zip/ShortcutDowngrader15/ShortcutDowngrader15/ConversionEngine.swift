import Foundation

/// iOS 16〜27 のショートカットを iOS 15 で取り込める形式に変換するエンジン。
///
/// やっていること:
///  1. WFWorkflowMinimumClientVersion などを iOS 15 世代へダウングレード
///  2. iOS 15 に無いアクションを、代替アクション / コメント / 削除 のいずれかに変換
///     - 置換・削除時も元の UUID を受け継ぐので、後続アクションの「前のアクションの出力」参照が切れない
///  3. iOS 18 以降の新形式「条件 (If)」パラメータを iOS 15 のフラット形式へ変換
///  4. iOS 15 が知らないパラメータキーを除去
///
/// 注意: Apple Intelligence や新しいシステム API 自体を iPhone 7 / iOS 15 で
/// 実行できるわけではない。該当アクションは代替手段に置き換わる。
enum ConversionEngine {

    static func convert(workflow original: [String: Any],
                        fileName: String,
                        policy: UnsupportedPolicy) throws -> ConversionOutcome {
        var workflow = original
        var reports: [ActionReport] = []

        // ---- 1. バージョン情報を iOS 15 世代へ ----
        workflow["WFWorkflowMinimumClientVersion"] = 866
        workflow.removeValue(forKey: "WFWorkflowMinimumClientVersionString")
        workflow["WFWorkflowClientVersion"] = "1146.11"
        workflow["WFWorkflowClientRelease"] = "15.0.0"
        // iOS 16 以降で追加されたワークフロー単位のキー
        for key in ["WFWorkflowHasOutputFallback", "WFWorkflowJitRequired",
                    "WFQuickActionTypes", "WFWorkflowAppDescriptor"] {
            workflow.removeValue(forKey: key)
        }
        // アイコンのグリフが新しすぎる場合は汎用グリフに差し替える
        if var icon = workflow["WFWorkflowIcon"] as? [String: Any] {
            if icon["WFWorkflowIconGlyphNumber"] == nil {
                icon["WFWorkflowIconGlyphNumber"] = 61440
            }
            if icon["WFWorkflowIconStartColor"] == nil {
                icon["WFWorkflowIconStartColor"] = 4282601983
            }
            workflow["WFWorkflowIcon"] = icon
        }

        // ---- 2. アクション変換 ----
        let rawActions = workflow["WFWorkflowActions"] as? [[String: Any]] ?? []
        var newActions: [[String: Any]] = []
        newActions.reserveCapacity(rawActions.count)

        for (index, action) in rawActions.enumerated() {
            let identifier = action["WFWorkflowActionIdentifier"] as? String ?? ""
            var parameters = action["WFWorkflowActionParameters"] as? [String: Any] ?? [:]
            let uuid = parameters["UUID"] as? String

            // 4. 未知パラメータキーの除去 (既存アクションでも行う)
            var stripped: [String] = []
            for key in Array(parameters.keys) where ActionCatalog.parameterKeysToStrip.contains(key) {
                parameters.removeValue(forKey: key)
                stripped.append(key)
            }

            // 3. If アクションの新形式条件をフラット化
            if identifier == "is.workflow.actions.conditional" {
                if let flattened = flattenConditions(parameters) {
                    parameters = flattened
                    reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                                decision: .parametersFixed, replacementIdentifier: nil,
                                                note: "iOS 18 以降形式の条件を iOS 15 形式に変換"))
                }
            }

            if isSupportedOn15(identifier) {
                if !stripped.isEmpty {
                    reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                                decision: .parametersFixed, replacementIdentifier: nil,
                                                note: "未知パラメータを除去: \(stripped.joined(separator: ", "))"))
                }
                newActions.append(makeAction(identifier, parameters))
                continue
            }

            // ---- iOS 15 に無いアクション ----
            let introduced = ActionCatalog.introducedAfter15[identifier]
            let reason = introduced.map { "iOS \(formatVersion($0)) で追加" } ?? "iOS 15 に無いアクション"

            // 専用の置換処理があるもの
            if let special = specialReplacement(identifier: identifier,
                                                parameters: parameters, uuid: uuid) {
                newActions.append(contentsOf: special.actions)
                reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                            decision: .replaced,
                                            replacementIdentifier: special.actions.first?["WFWorkflowActionIdentifier"] as? String,
                                            note: "\(reason)。\(special.note)"))
                continue
            }
            if policy == .replaceWithFallback,
               let replacement = ActionCatalog.directReplacement[identifier] {
                var newParams: [String: Any] = ["WFInput": parameters["WFInput"] ?? ""]
                if let uuid { newParams["UUID"] = uuid }
                newActions.append(makeAction(replacement, newParams))
                reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                            decision: .replaced, replacementIdentifier: replacement,
                                            note: "\(reason)。iOS 15 の同等アクションに置換"))
                continue
            }

            switch policy {
            case .keepAsIs:
                newActions.append(makeAction(identifier, parameters))
                reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                            decision: .kept, replacementIdentifier: nil,
                                            note: "\(reason)。そのまま残したので取り込みに失敗する可能性あり"))
            case .remove:
                // 参照切れ防止: UUID を持つ空コメントを置く
                newActions.append(commentAction(text: "［削除］\(identifier)（\(reason)）", uuid: uuid))
                reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                            decision: .removed, replacementIdentifier: nil,
                                            note: reason))
            case .replaceWithFallback, .commentOut:
                newActions.append(commentAction(
                    text: "［iOS 15 非対応］\(identifier)（\(reason)）元の設定: \(describeParameters(parameters))",
                    uuid: uuid))
                reports.append(ActionReport(index: index, originalIdentifier: identifier,
                                            decision: .commented, replacementIdentifier: nil,
                                            note: "\(reason)。コメント化したので手動で組み直し可能"))
            }
        }

        workflow["WFWorkflowActions"] = newActions
        let data = try ShortcutParser.serialize(workflow)
        let base = (fileName as NSString).deletingPathExtension
        return ConversionOutcome(workflowName: base,
                                 outputData: data,
                                 outputFileName: "\(base)-iOS15.shortcut",
                                 reports: reports,
                                 totalActions: rawActions.count)
    }

    // MARK: - 判定

    static func isSupportedOn15(_ identifier: String) -> Bool {
        if ActionCatalog.introducedAfter15[identifier] != nil { return false }
        if ActionCatalog.knownIn15.contains(identifier) { return true }
        if identifier.hasPrefix("is.workflow.actions.") {
            // ホワイトリストに無い workflow アクションは新しい可能性が高い
            return false
        }
        // App Intents 形式 (例: com.apple.clock.CreateAlarmAction,
        // com.openai.chat.AskChatGPTAction) は iOS 16 以降の仕組み
        if identifier.contains("Action") || identifier.contains("Intent") { return false }
        // それ以外のサードパーティ SiriKit アクションは iOS 15 でも動くものがあるため残す
        return true
    }

    // MARK: - 専用置換

    private struct SpecialResult { var actions: [[String: Any]]; var note: String }

    private static func specialReplacement(identifier: String,
                                           parameters: [String: Any],
                                           uuid: String?) -> SpecialResult? {
        let lower = identifier.lowercased()

        // 「停止して出力」(iOS 16) -> 「結果を表示」+「ショートカットを終了」
        if identifier == "is.workflow.actions.output" {
            var showParams: [String: Any] = [:]
            if let input = parameters["WFInput"] { showParams["WFInput"] = input }
            if let uuid { showParams["UUID"] = uuid }
            return SpecialResult(actions: [makeAction("is.workflow.actions.showresult", showParams),
                                           makeAction("is.workflow.actions.exit", [:])],
                                 note: "「結果を表示」+「終了」に分解")
        }

        // AI 系 (Apple Intelligence / ChatGPT 等) -> 「入力を要求」
        // iPhone 7 ではモデル自体は動かないが、プロンプトを手入力に置き換えれば流れは維持できる
        if lower.contains("chatgpt") || lower.contains("intelligence") ||
           lower.contains("usemodel") || lower.contains("askllm") ||
           lower.contains("askmodel") || lower.contains("writingtools") {
            let prompt = firstString(in: parameters, keys: ["WFAskActionPrompt", "WFPrompt", "Prompt", "WFText"])
                ?? "元の AI アクションへの入力を入力してください"
            var askParams: [String: Any] = ["WFInputType": "Text", "WFAskActionPrompt": prompt]
            if let uuid { askParams["UUID"] = uuid }
            return SpecialResult(actions: [makeAction("is.workflow.actions.ask", askParams)],
                                 note: "AI アクションは iOS 15 に無いため「入力を要求」に置換（プロンプトは引き継ぎ）")
        }

        // 画像生成系 -> 代替なし (コメント)
        if lower.contains("imageplayground") || lower.contains("genmoji") || lower.contains("createimage") {
            return SpecialResult(actions: [commentAction(text: "［代替なし］画像生成アクション \(identifier) は iOS 15 / iPhone 7 では実行できません", uuid: uuid)],
                                 note: "画像生成は代替手段がないためコメント化")
        }

        // コントロールセンター系トグル (iOS 18) -> 個別の旧アクションへ
        if lower.contains("controlcenter") || lower.contains("toggle") {
            let haystack = (identifier + " " + describeParameters(parameters)).lowercased()
            let map: [(String, String)] = [
                ("wifi", "is.workflow.actions.wifi.set"),
                ("bluetooth", "is.workflow.actions.bluetooth.set"),
                ("airplane", "is.workflow.actions.airplanemode.set"),
                ("lowpower", "is.workflow.actions.lowpowermode.set"),
                ("donotdisturb", "is.workflow.actions.dnd.set"),
                ("focus", "is.workflow.actions.dnd.set"),
            ]
            for (keyword, replacement) in map where haystack.contains(keyword) {
                var newParams: [String: Any] = ["WFOnState": true]
                if let uuid { newParams["UUID"] = uuid }
                return SpecialResult(actions: [makeAction(replacement, newParams)],
                                     note: "コントロールセンター項目を iOS 15 の「\(replacement)」に置換（ON/OFF は要確認）")
            }
        }
        return nil
    }

    // MARK: - 条件 (If) のフラット化

    /// iOS 18 以降: WFConditions が { WFConditionGroups: [...] } の入れ子形式になることがある。
    /// iOS 15 形式: WFConditions は条件ディクショナリの配列。
    private static func flattenConditions(_ parameters: [String: Any]) -> [String: Any]? {
        guard let conditions = parameters["WFConditions"] as? [String: Any] else { return nil }
        var flat: [[String: Any]] = []
        func collect(from dict: [String: Any]) {
            if let groups = dict["WFConditionGroups"] as? [[String: Any]] {
                groups.forEach(collect)
            }
            if let items = dict["WFConditions"] as? [[String: Any]] {
                for item in items {
                    if item["WFConditionGroups"] != nil || item["WFConditions"] is [String: Any] {
                        collect(from: item)
                    } else {
                        flat.append(item)
                    }
                }
            }
            if dict["WFCondition"] != nil { flat.append(dict) }
        }
        collect(from: conditions)
        guard !flat.isEmpty else { return nil }
        var newParameters = parameters
        newParameters["WFConditions"] = flat
        return newParameters
    }

    // MARK: - ヘルパー

    private static func makeAction(_ identifier: String, _ parameters: [String: Any]) -> [String: Any] {
        ["WFWorkflowActionIdentifier": identifier, "WFWorkflowActionParameters": parameters]
    }

    private static func commentAction(text: String, uuid: String?) -> [String: Any] {
        var params: [String: Any] = ["WFCommentActionText": text]
        if let uuid { params["UUID"] = uuid }
        return makeAction("is.workflow.actions.comment", params)
    }

    private static func firstString(in dict: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let value = dict[key] as? String, !value.isEmpty { return value }
            if let token = dict[key] as? [String: Any],
               let string = token["string"] as? String, !string.isEmpty { return string }
        }
        return nil
    }

    private static func describeParameters(_ parameters: [String: Any]) -> String {
        let keys = parameters.keys.filter { $0 != "UUID" }.sorted()
        return keys.isEmpty ? "(パラメータなし)" : keys.joined(separator: ", ")
    }

    private static func formatVersion(_ version: Double) -> String {
        version == floor(version) ? String(Int(version)) : String(version)
    }
}
