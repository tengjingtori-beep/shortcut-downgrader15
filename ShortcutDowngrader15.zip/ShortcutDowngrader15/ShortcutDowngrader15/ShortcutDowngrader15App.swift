import SwiftUI

@main
struct ShortcutDowngrader15App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
