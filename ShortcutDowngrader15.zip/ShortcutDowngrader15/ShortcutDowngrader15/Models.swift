import Foundation

/// 互換性のないアクションをどう処理するか (画面で選択)
enum UnsupportedPolicy: String, CaseIterable, Identifiable {
    /// 同等機能があれば置換、無ければコメント化 (推奨)
    case replaceWithFallback
    /// コメント化して必ず残す (何があったか分かる)
    case commentOut
    /// 削除する (UUID はコメントで受けるので参照は壊れない)
    case remove
    /// そのまま残す (取り込みに失敗する可能性あり)
    case keepAsIs

    var id: String { rawValue }

    var label: String {
        switch self {
        case .replaceWithFallback: return "代替アクションに置換（推奨）"
        case .commentOut: return "コメントに置き換える"
        case .remove: return "削除する"
        case .keepAsIs: return "そのまま残す（危険）"
        }
    }
}

enum ActionDecision: String {
    case kept = "そのまま"
    case replaced = "置換"
    case commented = "コメント化"
    case removed = "削除"
    case parametersFixed = "パラメータ修正"
}

struct ActionReport: Identifiable {
    let id = UUID()
    let index: Int
    let originalIdentifier: String
    let decision: ActionDecision
    let replacementIdentifier: String?
    let note: String
}

struct ConversionOutcome {
    var workflowName: String
    var outputData: Data
    var outputFileName: String
    var reports: [ActionReport]
    var totalActions: Int

    var changedCount: Int { reports.filter { $0.decision != .kept }.count }
}
