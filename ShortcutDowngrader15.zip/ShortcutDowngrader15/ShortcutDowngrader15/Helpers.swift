import SwiftUI
import UniformTypeIdentifiers

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

extension UTType {
    /// .shortcut / .wflow をまとめて扱うためのタイプ
    static var shortcutFile: UTType {
        UTType(filenameExtension: "shortcut") ?? UTType(filenameExtension: "wflow") ?? .data
    }
}
