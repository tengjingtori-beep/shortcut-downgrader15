import Foundation

enum ShortcutParserError: LocalizedError {
    case notAShortcut
    case signedButNotExtractable

    var errorDescription: String? {
        switch self {
        case .notAShortcut:
            return "ショートカットファイルとして読み込めませんでした。"
        case .signedButNotExtractable:
            return "署名付きショートカットから本体を取り出せませんでした。iCloud リンク経由の未署名ファイル (.wflow / プリスト形式) で試してください。"
        }
    }
}

/// .shortcut / .wflow ファイルから WFWorkflow プリストを取り出す。
enum ShortcutParser {

    static func extractWorkflow(from raw: Data) throws -> [String: Any] {
        // 1) そのままプリストとして読める場合 (未署名 .shortcut / .wflow)
        if let workflow = parsePlist(raw) { return workflow }

        // 2) 署名付き .shortcut: AEA コンテナ内に埋め込まれた bplist / XML を探す
        //    署名専用プロファイルでは本体は平文で格納されているため、この走査で取り出せる。
        for magic in ["bplist00", "<?xml"] {
            if let range = raw.range(of: Data(magic.utf8)),
               let workflow = parsePlist(raw.subdata(in: range.lowerBound..<raw.count)) {
                return workflow
            }
        }
        throw ShortcutParserError.signedButNotExtractable
    }

    static func serialize(_ workflow: [String: Any]) throws -> Data {
        try PropertyListSerialization.data(fromPropertyList: workflow,
                                           format: .binary, options: 0)
    }

    private static func parsePlist(_ data: Data) -> [String: Any]? {
        var format = PropertyListSerialization.PropertyListFormat.binary
        guard let object = try? PropertyListSerialization.propertyList(from: data,
                                                                       options: [],
                                                                       format: &format),
              let dict = object as? [String: Any],
              dict["WFWorkflowActions"] is [Any] else { return nil }
        return dict
    }
}
