import Foundation

/// iOS 15 のショートカットアプリに存在しないアクションのカタログ。
/// ここに無いものでも、ConversionEngine が
/// (1) iOS 15 ホワイトリストに無い `is.workflow.actions.*`
/// (2) App Intents 形式 (iOS 16 以降) の識別子
/// を検出して処理するので、カタログは代表例でよい。
/// 新しい iOS のアクションを見つけたらここへ 1 行足すだけで対応できる。
enum ActionCatalog {

    /// アクション識別子 -> 登場した iOS バージョン (15 より大きいものだけ)
    static let introducedAfter15: [String: Double] = [
        // iOS 16
        "is.workflow.actions.output": 16.0,                 // 停止して出力
        "is.workflow.actions.getfocus": 16.0,               // 集中モードを取得
        "is.workflow.actions.listeningmode.set": 16.0,      // ノイズコントロール
        "is.workflow.actions.backgroundsounds.set": 16.0,   // バックグラウンドサウンド
        "is.workflow.actions.speechtotext": 16.4,           // (新形式の音声テキスト変換)

        // iOS 17
        "is.workflow.actions.transcribeaudio": 17.0,        // オーディオを転写
        "is.workflow.actions.getonscreencontent": 17.0,     // 画面上のコンテンツを取得
        "is.workflow.actions.getlastscreenshot": 17.0,
        "is.workflow.actions.setairplanemodev2": 17.0,

        // iOS 18
        "is.workflow.actions.getcurrentapp": 18.0,          // 現在の App を取得
        "is.workflow.actions.hideapps": 18.0,               // App を非表示
        "is.workflow.actions.opencontrolcenter": 18.0,      // コントロールセンター項目
        "is.workflow.actions.iflink": 18.0,

        // iOS 26 / 27 (Apple Intelligence 系)
        "is.workflow.actions.appleintelligence.usemodel": 26.0,
        "is.workflow.actions.appleintelligence.ask": 26.0,
        "is.workflow.actions.usemodel": 26.0,
        "is.workflow.actions.askllm": 26.0,
        "is.workflow.actions.writingtools.rewrite": 26.0,
        "is.workflow.actions.imageplayground.create": 26.0,
        "is.workflow.actions.genmoji.create": 26.0,
        "is.workflow.actions.summarize": 26.0,
    ]

    /// iOS 15 に実在する代表的なアクション (ホワイトリスト)。
    /// ここにあって introducedAfter15 に無いものはそのまま残す。
    /// ここに無い `is.workflow.actions.*` は「未知 = 新しい可能性が高い」として報告対象にする。
    static let knownIn15: Set<String> = [
        "is.workflow.actions.comment", "is.workflow.actions.text",
        "is.workflow.actions.ask", "is.workflow.actions.showresult",
        "is.workflow.actions.showalert", "is.workflow.actions.notification",
        "is.workflow.actions.exit", "is.workflow.actions.openurl",
        "is.workflow.actions.getclipboard", "is.workflow.actions.setclipboard",
        "is.workflow.actions.conditional", "is.workflow.actions.repeat",
        "is.workflow.actions.repeat.count", "is.workflow.actions.repeat.each",
        "is.workflow.actions.choosefrommenu", "is.workflow.actions.choosefromlist",
        "is.workflow.actions.list", "is.workflow.actions.getitemfromlist",
        "is.workflow.actions.count", "is.workflow.actions.calculate",
        "is.workflow.actions.number", "is.workflow.actions.setvariable",
        "is.workflow.actions.getvariable", "is.workflow.actions.appendvariable",
        "is.workflow.actions.runworkflow", "is.workflow.actions.openapp",
        "is.workflow.actions.launchapp", "is.workflow.actions.url",
        "is.workflow.actions.getcontentssofurl", "is.workflow.actions.downloadurl",
        "is.workflow.actions.getcurrentdate", "is.workflow.actions.date",
        "is.workflow.actions.format.date", "is.workflow.actions.adjustdate",
        "is.workflow.actions.detect.dictionary", "is.workflow.actions.getvalueforkey",
        "is.workflow.actions.setvalueforkey", "is.workflow.actions.dictionary",
        "is.workflow.actions.base64encode", "is.workflow.actions.hash",
        "is.workflow.actions.splittext", "is.workflow.actions.combinetext",
        "is.workflow.actions.replace", "is.workflow.actions.matchtext",
        "is.workflow.actions.gettextfrominput", "is.workflow.actions.speaktext",
        "is.workflow.actions.dictate", "is.workflow.actions.getdevicename",
        "is.workflow.actions.getdevicedetails", "is.workflow.actions.getbatterylevel",
        "is.workflow.actions.getipaddress", "is.workflow.actions.wifi.set",
        "is.workflow.actions.bluetooth.set", "is.workflow.actions.airplanemode.set",
        "is.workflow.actions.cellular.set", "is.workflow.actions.lowpowermode.set",
        "is.workflow.actions.dnd.set", "is.workflow.actions.setfocus",
        "is.workflow.actions.appearance.set", "is.workflow.actions.brightness.set",
        "is.workflow.actions.volume.set", "is.workflow.actions.flashlight",
        "is.workflow.actions.orientationlock.set", "is.workflow.actions.nfc.scan",
        "is.workflow.actions.takephoto", "is.workflow.actions.takevideo",
        "is.workflow.actions.selectphoto", "is.workflow.actions.getlatestphotos",
        "is.workflow.actions.getlatestbursts", "is.workflow.actions.getlatestscreenshots",
        "is.workflow.actions.getlatestlivephotos", "is.workflow.actions.getlatestvideos",
        "is.workflow.actions.savephoto", "is.workflow.actions.resizeimage",
        "is.workflow.actions.cropimage", "is.workflow.actions.rotateimage",
        "is.workflow.actions.convertimage", "is.workflow.actions.removebackground",
        "is.workflow.actions.extracttextfromimage", "is.workflow.actions.makezip",
        "is.workflow.actions.unarchive", "is.workflow.actions.documentpicker.open",
        "is.workflow.actions.documentpicker.save", "is.workflow.actions.getfile",
        "is.workflow.actions.deletefile", "is.workflow.actions.movefile",
        "is.workflow.actions.renamefile", "is.workflow.actions.file.append",
        "is.workflow.actions.getdirections", "is.workflow.actions.getdistance",
        "is.workflow.actions.gettraveltime", "is.workflow.actions.address",
        "is.workflow.actions.location.get", "is.workflow.actions.weather.currentconditions",
        "is.workflow.actions.weather.forecast", "is.workflow.actions.sendmessage",
        "is.workflow.actions.sendemail", "is.workflow.actions.facetime",
        "is.workflow.actions.call", "is.workflow.actions.addnewevent",
        "is.workflow.actions.getupcomingevents", "is.workflow.actions.addnewreminder",
        "is.workflow.actions.getupcomingreminders", "is.workflow.actions.addnewnote",
        "is.workflow.actions.appendnote", "is.workflow.actions.shownote",
        "is.workflow.actions.playmusic", "is.workflow.actions.pausemusic",
        "is.workflow.actions.skipback", "is.workflow.actions.skipforward",
        "is.workflow.actions.setplaybackdestination", "is.workflow.actions.handoffplayback",
        "is.workflow.actions.airdrop", "is.workflow.actions.share",
        "is.workflow.actions.shareextension", "is.workflow.actions.vibrate",
        "is.workflow.actions.wait", "is.workflow.actions.delay",
        "is.workflow.actions.nothing", "is.workflow.actions.setwallpaper",
        "is.workflow.actions.screenshot", "is.workflow.actions.recordaudio",
        "is.workflow.actions.encodeaudio", "is.workflow.actions.encodemedia",
        "is.workflow.actions.trimmedia", "is.workflow.actions.makegif",
        "is.workflow.actions.makevideofromgif", "is.workflow.actions.rss",
        "is.workflow.actions.getarticle", "is.workflow.actions.getwebpagecontents",
        "is.workflow.actions.safari.geturl", "is.workflow.actions.openin",
        "is.workflow.actions.properties.icalendar", "is.workflow.actions.properties.contacts",
        "is.workflow.actions.properties.itunes", "is.workflow.actions.properties.maps",
        "is.workflow.actions.filter.calendarevents", "is.workflow.actions.filter.contacts",
        "is.workflow.actions.filter.files", "is.workflow.actions.filter.images",
        "is.workflow.actions.filter.music", "is.workflow.actions.filter.notes",
        "is.workflow.actions.filter.photos", "is.workflow.actions.filter.reminders",
        "is.workflow.actions.getname", "is.workflow.actions.gettype",
        "is.workflow.actions.setname", "is.workflow.actions.randomnumber",
        "is.workflow.actions.generatebarcode", "is.workflow.actions.scanbarcode",
        "is.workflow.actions.print", "is.workflow.actions.makepdf",
        "is.workflow.actions.getlinktorichtext", "is.workflow.actions.getrichtextfrommarkdown",
        "is.workflow.actions.getrichtextfromhtml", "is.workflow.actions.gethtmlfromrichtext",
        "is.workflow.actions.getmarkdownfromrichtext", "is.workflow.actions.viewresult",
        "is.workflow.actions.previewdocument", "is.workflow.actions.quicklook",
        "is.workflow.actions.getframesfromimage", "is.workflow.actions.combineimages",
        "is.workflow.actions.maskimage", "is.workflow.actions.overlaytextonimage",
        "is.workflow.actions.detectlanguage", "is.workflow.actions.translate",
        "is.workflow.actions.correctspelling", "is.workflow.actions.define",
        "is.workflow.actions.getphonenumbersfrominput", "is.workflow.actions.getemailsfrominput",
        "is.workflow.actions.geturlsfrominput", "is.workflow.actions.getdatesfrominput",
        "is.workflow.actions.getaddressesfrominput", "is.workflow.actions.getcontactsfrominput",
    ]

    /// iOS 15 にも同等機能がある新アクション -> 代替アクション識別子
    static let directReplacement: [String: String] = [
        "is.workflow.actions.transcribeaudio": "is.workflow.actions.dictate",
        "is.workflow.actions.speechtotext": "is.workflow.actions.dictate",
        "is.workflow.actions.getonscreencontent": "is.workflow.actions.getclipboard",
        "is.workflow.actions.getfocus": "is.workflow.actions.comment",
    ]

    /// 新形式のパラメータキーのうち、iOS 15 では未知で読み込みエラーの原因になるもの
    static let parameterKeysToStrip: Set<String> = [
        "WFAppIntentDescriptor", "AppIntentDescriptor",
        "WFExecutionContext", "WFIntentsActionDescriptor",
        "WFContentAttributionSet", "WFSuggestedActionData",
    ]
}
