#!/usr/bin/env python3
"""iOS 16〜27 のショートカットを iOS 15 形式へ変換する CLI (アプリ内エンジンと同じロジック)。

使い方:
  python3 shortcut_downgrade.py input.shortcut -o output.shortcut [--policy replace|comment|remove|keep]
  python3 shortcut_downgrade.py input.shortcut --report report.json   # 変換せずレポートだけ出すことも可

未署名プリスト形式 (.shortcut / .wflow) と、署名付きファイル内に平文で埋め込まれた
bplist / XML を取り出せる場合に対応する。
"""
import argparse, json, plistlib, sys

INTRODUCED_AFTER_15 = {
    "is.workflow.actions.output": 16.0,
    "is.workflow.actions.getfocus": 16.0,
    "is.workflow.actions.listeningmode.set": 16.0,
    "is.workflow.actions.backgroundsounds.set": 16.0,
    "is.workflow.actions.speechtotext": 16.4,
    "is.workflow.actions.transcribeaudio": 17.0,
    "is.workflow.actions.getonscreencontent": 17.0,
    "is.workflow.actions.getlastscreenshot": 17.0,
    "is.workflow.actions.getcurrentapp": 18.0,
    "is.workflow.actions.hideapps": 18.0,
    "is.workflow.actions.opencontrolcenter": 18.0,
    "is.workflow.actions.appleintelligence.usemodel": 26.0,
    "is.workflow.actions.appleintelligence.ask": 26.0,
    "is.workflow.actions.usemodel": 26.0,
    "is.workflow.actions.askllm": 26.0,
    "is.workflow.actions.writingtools.rewrite": 26.0,
    "is.workflow.actions.imageplayground.create": 26.0,
    "is.workflow.actions.genmoji.create": 26.0,
    "is.workflow.actions.summarize": 26.0,
}
KNOWN_IN_15 = {
    "is.workflow.actions.comment", "is.workflow.actions.text", "is.workflow.actions.ask",
    "is.workflow.actions.showresult", "is.workflow.actions.showalert",
    "is.workflow.actions.notification", "is.workflow.actions.exit",
    "is.workflow.actions.openurl", "is.workflow.actions.getclipboard",
    "is.workflow.actions.setclipboard", "is.workflow.actions.conditional",
    "is.workflow.actions.repeat", "is.workflow.actions.repeat.count",
    "is.workflow.actions.repeat.each", "is.workflow.actions.choosefrommenu",
    "is.workflow.actions.choosefromlist", "is.workflow.actions.list",
    "is.workflow.actions.getitemfromlist", "is.workflow.actions.count",
    "is.workflow.actions.calculate", "is.workflow.actions.number",
    "is.workflow.actions.setvariable", "is.workflow.actions.getvariable",
    "is.workflow.actions.appendvariable", "is.workflow.actions.runworkflow",
    "is.workflow.actions.openapp", "is.workflow.actions.url",
    "is.workflow.actions.getcurrentdate", "is.workflow.actions.date",
    "is.workflow.actions.format.date", "is.workflow.actions.adjustdate",
    "is.workflow.actions.dictionary", "is.workflow.actions.getvalueforkey",
    "is.workflow.actions.setvalueforkey", "is.workflow.actions.base64encode",
    "is.workflow.actions.hash", "is.workflow.actions.splittext",
    "is.workflow.actions.combinetext", "is.workflow.actions.replace",
    "is.workflow.actions.matchtext", "is.workflow.actions.speaktext",
    "is.workflow.actions.dictate", "is.workflow.actions.getbatterylevel",
    "is.workflow.actions.wifi.set", "is.workflow.actions.bluetooth.set",
    "is.workflow.actions.airplanemode.set", "is.workflow.actions.cellular.set",
    "is.workflow.actions.lowpowermode.set", "is.workflow.actions.dnd.set",
    "is.workflow.actions.setfocus", "is.workflow.actions.appearance.set",
    "is.workflow.actions.brightness.set", "is.workflow.actions.volume.set",
    "is.workflow.actions.flashlight", "is.workflow.actions.takephoto",
    "is.workflow.actions.selectphoto", "is.workflow.actions.savephoto",
    "is.workflow.actions.resizeimage", "is.workflow.actions.extracttextfromimage",
    "is.workflow.actions.makezip", "is.workflow.actions.unarchive",
    "is.workflow.actions.getfile", "is.workflow.actions.sendmessage",
    "is.workflow.actions.sendemail", "is.workflow.actions.call",
    "is.workflow.actions.addnewevent", "is.workflow.actions.addnewreminder",
    "is.workflow.actions.addnewnote", "is.workflow.actions.playmusic",
    "is.workflow.actions.wait", "is.workflow.actions.nothing",
    "is.workflow.actions.setwallpaper", "is.workflow.actions.screenshot",
    "is.workflow.actions.makepdf", "is.workflow.actions.share",
    "is.workflow.actions.vibrate", "is.workflow.actions.getname",
    "is.workflow.actions.randomnumber", "is.workflow.actions.translate",
    "is.workflow.actions.detectlanguage", "is.workflow.actions.quicklook",
}
DIRECT_REPLACEMENT = {
    "is.workflow.actions.transcribeaudio": "is.workflow.actions.dictate",
    "is.workflow.actions.speechtotext": "is.workflow.actions.dictate",
    "is.workflow.actions.getonscreencontent": "is.workflow.actions.getclipboard",
    "is.workflow.actions.getfocus": "is.workflow.actions.comment",
}
STRIP_KEYS = {"WFAppIntentDescriptor", "AppIntentDescriptor", "WFExecutionContext",
              "WFIntentsActionDescriptor", "WFContentAttributionSet", "WFSuggestedActionData"}


def extract(raw: bytes) -> dict:
    for chunk in (raw,):
        try:
            obj = plistlib.loads(chunk)
            if isinstance(obj, dict) and "WFWorkflowActions" in obj:
                return obj
        except Exception:
            pass
    for magic in (b"bplist00", b"<?xml"):
        idx = raw.find(magic)
        if idx >= 0:
            try:
                obj = plistlib.loads(raw[idx:])
                if isinstance(obj, dict) and "WFWorkflowActions" in obj:
                    return obj
            except Exception:
                pass
    raise SystemExit("ショートカットとして読み込めませんでした（署名付きで取り出せない形式の可能性があります）")


def supported(identifier: str) -> bool:
    if identifier in INTRODUCED_AFTER_15:
        return False
    if identifier in KNOWN_IN_15:
        return True
    if identifier.startswith("is.workflow.actions."):
        return False
    if "Action" in identifier or "Intent" in identifier:
        return False
    return True


def make(identifier, params):
    return {"WFWorkflowActionIdentifier": identifier, "WFWorkflowActionParameters": params}


def comment(text, uuid=None):
    params = {"WFCommentActionText": text}
    if uuid:
        params["UUID"] = uuid
    return make("is.workflow.actions.comment", params)


def flatten_conditions(params):
    cond = params.get("WFConditions")
    if not isinstance(cond, dict):
        return None
    flat = []
    def collect(d):
        for g in d.get("WFConditionGroups", []) or []:
            if isinstance(g, dict):
                collect(g)
        items = d.get("WFConditions")
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict) and ("WFConditionGroups" in item or isinstance(item.get("WFConditions"), dict)):
                    collect(item)
                elif isinstance(item, dict):
                    flat.append(item)
        if "WFCondition" in d:
            flat.append(d)
    collect(cond)
    if not flat:
        return None
    new = dict(params)
    new["WFConditions"] = flat
    return new


def special(identifier, params, uuid):
    lower = identifier.lower()
    if identifier == "is.workflow.actions.output":
        show = {}
        if "WFInput" in params:
            show["WFInput"] = params["WFInput"]
        if uuid:
            show["UUID"] = uuid
        return [make("is.workflow.actions.showresult", show), make("is.workflow.actions.exit", {})], "「結果を表示」+「終了」に分解"
    if any(k in lower for k in ("chatgpt", "intelligence", "usemodel", "askllm", "askmodel", "writingtools")):
        prompt = params.get("WFAskActionPrompt") or params.get("WFPrompt") or "元の AI アクションへの入力を入力してください"
        ask = {"WFInputType": "Text", "WFAskActionPrompt": prompt}
        if uuid:
            ask["UUID"] = uuid
        return [make("is.workflow.actions.ask", ask)], "AI アクションを「入力を要求」に置換"
    if any(k in lower for k in ("imageplayground", "genmoji", "createimage")):
        return [comment(f"［代替なし］画像生成アクション {identifier} は iOS 15 / iPhone 7 では実行できません", uuid)], "画像生成は代替なしのためコメント化"
    if "controlcenter" in lower or "toggle" in lower:
        haystack = (identifier + " " + " ".join(params.keys())).lower()
        for keyword, repl in (("wifi", "is.workflow.actions.wifi.set"),
                              ("bluetooth", "is.workflow.actions.bluetooth.set"),
                              ("airplane", "is.workflow.actions.airplanemode.set"),
                              ("lowpower", "is.workflow.actions.lowpowermode.set"),
                              ("donotdisturb", "is.workflow.actions.dnd.set"),
                              ("focus", "is.workflow.actions.dnd.set")):
            if keyword in haystack:
                p = {"WFOnState": True}
                if uuid:
                    p["UUID"] = uuid
                return [make(repl, p)], f"コントロールセンター項目を {repl} に置換"
    return None


def convert(workflow: dict, policy: str):
    wf = dict(workflow)
    wf["WFWorkflowMinimumClientVersion"] = 866
    wf.pop("WFWorkflowMinimumClientVersionString", None)
    wf["WFWorkflowClientVersion"] = "1146.11"
    wf["WFWorkflowClientRelease"] = "15.0.0"
    for key in ("WFWorkflowHasOutputFallback", "WFWorkflowJitRequired", "WFQuickActionTypes", "WFWorkflowAppDescriptor"):
        wf.pop(key, None)
    reports, new_actions = [], []
    for index, action in enumerate(wf.get("WFWorkflowActions", [])):
        identifier = action.get("WFWorkflowActionIdentifier", "")
        params = dict(action.get("WFWorkflowActionParameters", {}) or {})
        uuid = params.get("UUID")
        stripped = [k for k in list(params) if k in STRIP_KEYS]
        for k in stripped:
            params.pop(k, None)
        if identifier == "is.workflow.actions.conditional":
            flat = flatten_conditions(params)
            if flat is not None:
                params = flat
                reports.append({"index": index, "identifier": identifier, "decision": "parametersFixed",
                                "note": "iOS 18 以降形式の条件を iOS 15 形式に変換"})
        if supported(identifier):
            if stripped:
                reports.append({"index": index, "identifier": identifier, "decision": "parametersFixed",
                                "note": f"未知パラメータを除去: {', '.join(stripped)}"})
            new_actions.append(make(identifier, params))
            continue
        introduced = INTRODUCED_AFTER_15.get(identifier)
        reason = f"iOS {introduced:g} で追加" if introduced else "iOS 15 に無いアクション"
        sp = special(identifier, params, uuid)
        if sp:
            actions, note = sp
            new_actions.extend(actions)
            reports.append({"index": index, "identifier": identifier, "decision": "replaced", "note": f"{reason}。{note}"})
            continue
        if policy == "replace" and identifier in DIRECT_REPLACEMENT:
            repl = DIRECT_REPLACEMENT[identifier]
            p = {"WFInput": params.get("WFInput", "")}
            if uuid:
                p["UUID"] = uuid
            new_actions.append(make(repl, p))
            reports.append({"index": index, "identifier": identifier, "decision": "replaced",
                            "replacement": repl, "note": f"{reason}。iOS 15 の同等アクションに置換"})
            continue
        if policy == "keep":
            new_actions.append(make(identifier, params))
            reports.append({"index": index, "identifier": identifier, "decision": "kept", "note": reason})
        elif policy == "remove":
            new_actions.append(comment(f"［削除］{identifier}（{reason}）", uuid))
            reports.append({"index": index, "identifier": identifier, "decision": "removed", "note": reason})
        else:
            keys = ", ".join(sorted(k for k in params if k != "UUID")) or "(パラメータなし)"
            new_actions.append(comment(f"［iOS 15 非対応］{identifier}（{reason}）元の設定: {keys}", uuid))
            reports.append({"index": index, "identifier": identifier, "decision": "commented", "note": reason})
    wf["WFWorkflowActions"] = new_actions
    return wf, reports


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--policy", choices=["replace", "comment", "remove", "keep"], default="replace")
    ap.add_argument("--report")
    args = ap.parse_args()
    with open(args.input, "rb") as f:
        workflow = extract(f.read())
    converted, reports = convert(workflow, args.policy)
    if args.output:
        with open(args.output, "wb") as f:
            plistlib.dump(converted, f, fmt=plistlib.FMT_BINARY)
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(reports, f, ensure_ascii=False, indent=2)
    print(f"変換完了: 全 {len(workflow.get('WFWorkflowActions', []))} アクション中 {len(reports)} 件を変更")
    for r in reports:
        print(f"  - [{r['decision']}] {r['identifier']}: {r['note']}")


if __name__ == "__main__":
    main()
