# iPhone だけで IPA を作る手順（Mac 不要・無料・合法）

方法は **GitHub Actions** です。GitHub が用意した本物の Mac（Xcode 入り）を
クラウドで借りてビルドします。自分の Mac は要りません。
公開リポジトリなら macOS ランナーは無料です。Apple のライセンス違反になる
「Mac 以外で macOS を動かす」ような方法は使いません。

アップロードするファイルは **2 つだけ** にしてあります。

## 手順

### 1. GitHub アカウントを作る
- Safari で https://github.com を開き、Sign up（無料）
- メールアドレスとパスワードを登録し、確認メールの数字を入力

### 2. リポジトリを作る
- 右上の「+」→ New repository
- Repository name: `shortcut-downgrader15`（何でもよい）
- **Public** を選ぶ（無料でビルドするため。アプリのソースコードが公開されますが、
  秘密情報は含まれていません）
- Create repository

### 3. ワークフローファイルを作る
- リポジトリのページで「creating a new file」のリンク（または Add file → Create new file）
- ファイル名の欄に次を**正確に**入力:
  `.github/workflows/build-trollstore-ipa.yml`
  （スラッシュを打つと自動でフォルダになります）
- 大きな入力欄に、同梱の `workflowの内容.txt` の中身を**全部コピペ**
- 下の Commit changes を押す
- この時点ではまだビルドは走りません（ZIP を置いたときに走る設定です）。Actions タブに何も出なくても正常です

### 4. プロジェクト ZIP をアップロードする
- Add file → Upload files
- 同梱の `ShortcutDowngrader15.zip` を選ぶ（このファイル1個だけで OK。
  中のプロジェクトはビルド時に自動で展開されます）
- Commit changes を押す
- これで自動的にビルドが始まります（push トリガー）

### 5. IPA を受け取る
- リポジトリの **Actions** タブを開く
- 「Build TrollStore IPA」が緑のチェックになるまで待つ（10〜20分くらい）
- 開いて下の **Artifacts** → `ShortcutDowngrader15-tipa` をダウンロード
- 「ファイル」アプリで展開すると `ShortcutDowngrader15.tipa` が出ます

### 6. TrollStore でインストール
- `.tipa` を TrollStore で開く（共有メニューから TrollStore を選ぶ）
- Install を押せば完了。ホーム画面に「iOS15変換」が出ます

## もしビルドが失敗したら（赤いバツ）
- 同じ Actions の実行ページに `build-log` という Artifacts があります
- それをダウンロードして、はね（このチャット）に送ってください
- ログを見てプロジェクト側を直し、新しい ZIP を渡します

## うまくいかないときの確認
- ワークフローのファイル名が一字でも違うと動きません（手順3を再確認）
- Actions タブに何も出ない場合: リポジトリの Settings → Actions → General で
  Actions が許可されているか確認
- ダウンロードした ZIP が展開できない場合: 「ファイル」アプリで長押し →「圧縮解除」相当の操作、または一度タップで展開されます
